<?php include("includes/header.php") ?>

	 <?php include("includes/nav.php") ?>



	<div class="jumbotron">
		<h1 class="text-center"> <?php activate_user(); ?> </h1>
	</div>


	
<?php include("includes/footer.php") ?>