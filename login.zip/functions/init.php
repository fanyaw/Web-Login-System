<?php 

ob_start(); //output buffering
session_start();

include("db.php");
include("functions.php");



?>